#!/bin/bash
set -e
echo "=== Initializing environment ==="
mkdir -p /var/lib/litefs /var/log/app
cp -r ./database /var/lib/litefs/ || true
echo "=== Starting LiteFS with FastAPI ==="
exec litefs mount --config ./litefs.yml
